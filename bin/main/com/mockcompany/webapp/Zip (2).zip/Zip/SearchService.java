package com.mockcompany.webapp.controller;

public class SearchService {
    
}
